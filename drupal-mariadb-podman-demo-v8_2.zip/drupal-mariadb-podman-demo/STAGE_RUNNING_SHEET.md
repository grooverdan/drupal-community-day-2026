# Stage Running Sheet: "Be Lazy — Get the DB to Do That"
**Event:** DrupalSouth Community Day Canberra 2026 (Thursday, 19 Nov 2026 — Apollo Room, 14:50)  
**Presenter:** Daniel Black, Chief Innovation Officer, MariaDB Foundation  

---

## Pre-Stage Checklist (Before You Step Up)

1. **Confirm the stack is running:**
   ```bash
   podman ps
   ```
   Verify `canberra_drupal_php`, `canberra_mariadb`, and `canberra_ollama` are `Up`.

2. **Pull `nomic-embed-text` into Ollama (if not already cached in `ollama_data`) and run the self-test via `canberra_drupal_php`:**
   *(Note: `ollama/ollama` does not ship `curl`, so run the self-test from `canberra_drupal_php` across the Podman network.)*
   ```bash
   podman exec -it canberra_ollama ollama pull nomic-embed-text

   podman exec -it canberra_drupal_php curl -s http://ollama:11434/api/embed \
     -d '{"model": "nomic-embed-text", "input": "Serverless PHP automation and database architecture"}' | head -c 220
   ```
   **Expected output:** `{"model":"nomic-embed-text","embeddings":[[0.0124,-0.0481,...]]}`

3. **Open 4 Browser Tabs + 1 Split Terminal:**
   * **Tab 1:** `http://localhost:8080/mariadb-demo` *(Live view of `event_space_bookings` — also auto-syncs any new SQL-generated rows into Drupal nodes)*
   * **Tab 2:** `http://localhost:8080/node/18/edit` *(Daniel Black's session edit form — includes Title, Room, Speaker, Track, Abstract, and **Schedule Start / Stop Time**)*
   * **Tab 3:** `http://localhost:8080/admin/config/search/search-api` *(Search API server & index setup)*
   * **Tab 4:** `http://localhost:8080/session-search` *(Views semantic search page once created)*
   * **Terminal:** Connected to MariaDB (`podman exec -it canberra_mariadb mariadb -udrupal -pdrupal_password drupal`)

---

## Act 1: Application-Time Temporal Tables (`UNIQUE KEY ... WITHOUT OVERLAPS` & `FOR PORTION OF`)

**Narrative:** *"In Drupal, preventing double-bookings in the same room usually means transaction locks, range queries in PHP, and race conditions between two browser tabs. MariaDB uses `nid INT UNSIGNED AUTO_INCREMENT PRIMARY KEY` and enforces non-overlapping time windows per room natively via `UNIQUE KEY (room_code, booking_period WITHOUT OVERLAPS)`."*

### Step 1 — Inspect `event_space_bookings`
```sql
SHOW CREATE TABLE event_space_bookings\G

SELECT nid, room_code, event_title, speaker, valid_from, valid_to
FROM event_space_bookings
WHERE room_code = 'APOLLO'
ORDER BY valid_from;
```

### Step 2 — Race Condition Scenario: Partial Cancellation + Stale Tab Resubmission
Imagine **Organiser A** and **Organiser B** both open the afternoon Apollo schedule (`13:40 – 15:20`).
* **Organiser A** shortens Daniel's `14:50 – 15:20` slot by cancelling the final 15 minutes (`15:05 – 15:20`) using standard SQL:2011 `DELETE FOR PORTION OF`:
  ```sql
  DELETE FROM event_space_bookings
  FOR PORTION OF booking_period FROM '2026-11-19 15:05:00' TO '2026-11-19 15:20:00'
  WHERE room_code = 'APOLLO' AND speaker LIKE 'Daniel%';
  ```
* Immediately, **Lightning Talk Team** claims that newly freed `15:05 – 15:20` window in `APOLLO` (`nid` auto-increments cleanly):
  ```sql
  INSERT INTO event_space_bookings (room_code, event_title, speaker, track, summary, valid_from, valid_to)
  VALUES ('APOLLO', 'Community Lightning Talks', 'Various Speakers', 'Community', 'Rapid 5-minute community demos.', '2026-11-19 15:05:00', '2026-11-19 15:20:00');
  ```
* Meanwhile, **Organiser B** (whose browser tab was opened before the split) submits a modification extending Daniel's talk to `15:15`:
  ```sql
  UPDATE event_space_bookings
  SET valid_to = '2026-11-19 15:15:00'
  WHERE room_code = 'APOLLO' AND speaker LIKE 'Daniel%';
  ```
  **Result:** MariaDB immediately blocks the race condition with `ERROR 1062 (23000): Duplicate entry ... for key 'uq_room_booking_period'` — zero PHP locking code required.

### Step 3 — Surgical Mid-Session Split with `UPDATE FOR PORTION OF` + Auto-Node Sync
Split the `14:50 – 15:05` block cleanly so the second half becomes a live Q&A segment without manual row splitting:
```sql
UPDATE event_space_bookings
FOR PORTION OF booking_period FROM '2026-11-19 14:58:00' TO '2026-11-19 15:05:00'
SET event_title = 'Be Lazy - get the DB to do that (Live Q&A)'
WHERE room_code = 'APOLLO' AND speaker LIKE 'Daniel%';

SELECT nid, room_code, event_title, speaker, valid_from, valid_to
FROM event_space_bookings
WHERE room_code = 'APOLLO' AND valid_from >= '2026-11-19 14:50:00'
ORDER BY valid_from;
```
*(MariaDB automatically splits the row into two contiguous time slices and assigns the next auto-increment `nid`! Refresh **Tab 1** at `http://localhost:8080/mariadb-demo` — `canberra_events_sync_from_bookings()` immediately creates matching Drupal `session` nodes with those exact `nid`s so `/node/22/edit` and `/node/23/edit` work out of the box.)*

---

## Act 2: System-Versioned Tables (`ALTER TABLE ... ADD SYSTEM VERSIONING`)

**Narrative:** *"Now suppose compliance or conference organisers ask: who changed the schedule, when, and what did it say before? Instead of installing entity revision bloat or PHP audit hooks, we turn on System Versioning on the exact same table."*

### Step 1 — Alter `event_space_bookings` live to add System Versioning
```sql
ALTER TABLE event_space_bookings ADD SYSTEM VERSIONING;
```

### Step 2 — Modify a Session via the Drupal UI (including Stop/Start Time)
1. Switch to **Tab 2** (`http://localhost:8080/node/18/edit` — or click **Content** in the admin toolbar and edit *Be Lazy - get the DB to do that*).
2. Change **Session Title** to `Be Lazy - get the DB to do that (Extended Edition)` and adjust the **Schedule Start / Stop Time** widget on the form, then click **Save**.
   *(Our `canberra_events_node_update()` hook mirrors the Drupal entity save into `event_space_bookings`.)*

### Step 3 — Perform a Direct SQL Hotfix Outside Drupal PHP
Simulate a DBA or external API updating the speaker directly in SQL (bypassing Drupal's PHP layer completely):
```sql
UPDATE event_space_bookings
SET speaker = 'Daniel Black (MariaDB Foundation)'
WHERE speaker LIKE 'Daniel%';
```

### Step 4 — Time-Travel Query in SQL & Refresh `/mariadb-demo`
```sql
SELECT nid, event_title, speaker, valid_from, valid_to, ROW_START, ROW_END
FROM event_space_bookings FOR SYSTEM_TIME ALL
WHERE speaker LIKE 'Daniel%'
ORDER BY ROW_START DESC;
```
Switch to **Tab 1** (`http://localhost:8080/mariadb-demo`) and hit **Refresh**: the page automatically detects `SYSTEM VERSIONED` in `information_schema` and renders the complete `FOR SYSTEM_TIME ALL` audit history table.

---

## Act 3: Local Ollama + Native MariaDB Vector Search (`VECTOR(768) NOT NULL` + HNSW)

**Narrative:** *"Finally, let's add semantic AI search—again without standing up a separate Pinecone, Qdrant, or OpenSearch cluster. First we reset `event_space_bookings` cleanly back to the canonical 21 sessions, alter it to add a `VECTOR(768) NOT NULL` column with an HNSW index, and run semantic search through Drupal + Ollama."*

### Step 1 — Drop, Recreate, Repopulate, and Alter `event_space_bookings` with `VECTOR(768) NOT NULL`
In your MariaDB terminal:
```sql
DROP TABLE IF EXISTS event_space_bookings;

CREATE TABLE event_space_bookings (
    nid INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    room_code VARCHAR(32) NOT NULL,
    event_title VARCHAR(200) NOT NULL,
    speaker VARCHAR(150) NOT NULL,
    track VARCHAR(120) NOT NULL,
    summary TEXT NOT NULL,
    valid_from DATETIME NOT NULL,
    valid_to DATETIME NOT NULL,
    PERIOD FOR booking_period (valid_from, valid_to),
    UNIQUE KEY uq_room_booking_period (room_code, booking_period WITHOUT OVERLAPS)
) ENGINE=InnoDB;

-- Repopulate the 21 canonical sessions from Drupal's session nodes:
INSERT INTO event_space_bookings (nid, room_code, event_title, speaker, track, summary, valid_from, valid_to)
SELECT
  n.nid,
  r.field_room_value,
  n.title,
  s.field_speaker_value,
  t.field_track_value,
  b.body_value,
  REPLACE(w.field_schedule_window_value, 'T', ' '),
  REPLACE(w.field_schedule_window_end_value, 'T', ' ')
FROM node_field_data n
JOIN node__body b ON b.entity_id = n.nid
JOIN node__field_room r ON r.entity_id = n.nid
JOIN node__field_speaker s ON s.entity_id = n.nid
JOIN node__field_track t ON t.entity_id = n.nid
JOIN node__field_schedule_window w ON w.entity_id = n.nid
WHERE n.type = 'session' AND n.nid <= 21
ORDER BY n.nid;

-- Add NOT NULL VECTOR(768) column (defaulting to zero vector) and HNSW VECTOR INDEX:
ALTER TABLE event_space_bookings
  ADD COLUMN embedding VECTOR(768) NOT NULL DEFAULT VEC_FromText(CONCAT('[', REPEAT('0,', 767), '0]')),
  ADD VECTOR INDEX idx_session_embedding (embedding) M=16 DISTANCE=cosine;

SHOW CREATE TABLE event_space_bookings\G
```

### Step 2 — Configure Ollama & Add Search Server + Index in Drupal UI
1. **Configure Ollama Provider (`/admin/config/ai/providers/ollama`):**
   * **Host:** `http://ollama`
   * **Port:** `11434`
   * Click **Save configuration**.
2. **Add Search Server (`/admin/config/search/search-api` → `+ Add server`):**
   * **Server name:** `MariaDB Local Vector Server`
   * **Enabled:** Checked
   * **Backend:** Select **AI Search**
   * Under **Configure AI Search backend**:
     * **Vector DB Provider:** Select **MariaDB vector DB**
     * **Database Host / Port / Name / User / Password:** `mariadb` / `3306` / `drupal` / `drupal` / `drupal_password` *(or default Drupal DB connection)*
     * **Embeddings Engine:** Select **Ollama** → **`nomic-embed-text`**
     * **Embeddings Dimension:** **`768`**
     * **Metric:** `Cosine`
   * Click **Save**.
3. **Add Search Index (`/admin/config/search/search-api` → `+ Add index`):**
   * **Index name:** `Conference Sessions Semantic Index`
   * **Datasources:** Check **Content** → under **Bundles**, select **Only those selected → Conference Session** (`session`)
   * **Server:** Select **MariaDB Local Vector Server**
   * Click **Save and add fields**.
4. **Add Fields to Embed:**
   * Click **+ Add fields** → add **Title** (`title`), **Abstract / Summary** (`body`), **Speaker(s)** (`field_speaker`), and **Track** (`field_track`) → click **Done**.
   * Assign their AI Search indexing roles (**Main content** for Title & Abstract; **Contextual content** for Speaker & Track) → click **Save changes**.
5. **Index Sessions:**
   * Go to the Index **View** tab and click **Index now** (sends the sessions to `http://ollama:11434/api/embed` and stores the `768`-dim vectors in MariaDB).

### Step 3 — Run Semantic Search via Drupal Views (`/session-search`)
1. Go to **Structure → Views → + Add view** (`/admin/structure/views/add`):
   * **View name:** `Session Semantic Search`
   * **View settings → Show:** Select **Index Conference Sessions Semantic Index**
   * Check **Create a page** → **Path:** `session-search`
   * **Display format:** **Unformatted list** of **Rendered entity** (or **Fields**) → click **Save and edit**.
2. Under **Filter Criteria**, click **+ Add** → select **Fulltext search** (`search_api_fulltext`) → **Add and configure filter criteria** → check **Expose this filter to visitors, to allow them to change it** → click **Apply**, then **Save** the View.
3. Open **`http://localhost:8080/session-search`** in **Tab 4** and run zero-keyword-overlap queries:
   * *"making government websites safer against hackers"* → surfaces **Janna Malikova — GovCMS security features**
   * *"helping non-designers test prototypes with users"* → surfaces **Tori Sanderson — Ask six people: rapid testing for non-researchers**
   * *"letting the database handle concurrency and audit history"* → surfaces **Daniel Black — Be Lazy - get the DB to do that**
