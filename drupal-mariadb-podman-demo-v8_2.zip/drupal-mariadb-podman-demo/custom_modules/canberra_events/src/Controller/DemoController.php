<?php

namespace Drupal\canberra_events\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Database\Database;

/**
 * Syncs SQL-created bookings into Drupal nodes and renders live demo tables.
 */
class DemoController extends ControllerBase {

  public function overview(): array {
    // Materialise any new nids created by direct SQL (INSERT / UPDATE FOR PORTION OF)
    $synced_count = canberra_events_sync_from_bookings();

    $db = Database::getConnection();

    // Check if event_space_bookings currently has SYSTEM VERSIONING enabled
    $is_versioned = (bool) $db->query(
      "SELECT COUNT(*) FROM information_schema.TABLES
       WHERE TABLE_SCHEMA = DATABASE()
         AND TABLE_NAME = 'event_space_bookings'
         AND TABLE_TYPE = 'SYSTEM VERSIONED'"
    )->fetchField();

    $bookings = $db->query(
      "SELECT nid, room_code, event_title, speaker, valid_from, valid_to
       FROM {event_space_bookings}
       ORDER BY valid_from ASC, room_code ASC"
    )->fetchAll();

    $booking_rows = [];
    foreach ($bookings as $b) {
      $edit_link = $b->nid ? "/node/{$b->nid}/edit" : '-';
      $booking_rows[] = [
        $b->nid,
        $b->room_code,
        $b->event_title,
        $b->speaker,
        $b->valid_from,
        $b->valid_to,
        $edit_link,
      ];
    }

    $build = [];
    if ($synced_count > 0) {
      $build['sync_notice'] = [
        '#markup' => "<p><strong>Synced {$synced_count} new SQL-generated booking(s) into Drupal Conference Session nodes.</strong></p>",
      ];
    }

    $build['bookings_heading'] = ['#markup' => '<h2>1. Application-Time Temporal Schedule (event_space_bookings — UNIQUE KEY WITHOUT OVERLAPS)</h2>'];
    $build['bookings_table'] = [
      '#type' => 'table',
      '#header' => ['NID', 'Room', 'Session Title', 'Speaker', 'Start (valid_from)', 'Stop (valid_to)', 'Edit URL'],
      '#rows' => $booking_rows,
    ];

    if ($is_versioned) {
      $history = $db->query(
        "SELECT nid, room_code, event_title, speaker, valid_from, valid_to, ROW_START, ROW_END
         FROM {event_space_bookings} FOR SYSTEM_TIME ALL
         ORDER BY nid ASC, ROW_START DESC"
      )->fetchAll();

      $history_rows = [];
      foreach ($history as $h) {
        $history_rows[] = [
          $h->nid,
          $h->room_code,
          $h->event_title,
          $h->speaker,
          "{$h->valid_from} → {$h->valid_to}",
          $h->ROW_START,
          $h->ROW_END,
        ];
      }

      $build['history_heading'] = ['#markup' => '<h2>2. System-Versioned Audit Trail (FOR SYSTEM_TIME ALL on event_space_bookings)</h2>'];
      $build['history_table'] = [
        '#type' => 'table',
        '#header' => ['NID', 'Room', 'Session Title', 'Speaker', 'Booking Window', 'ROW_START', 'ROW_END'],
        '#rows' => $history_rows,
      ];
    }
    else {
      $build['versioning_notice'] = [
        '#markup' => '<p><em>System Versioning is not yet enabled on <code>event_space_bookings</code>. Run <code>ALTER TABLE event_space_bookings ADD SYSTEM VERSIONING;</code> before Demo 2 to unlock full historical time-travel below.</em></p>',
      ];
    }

    return $build;
  }

}
