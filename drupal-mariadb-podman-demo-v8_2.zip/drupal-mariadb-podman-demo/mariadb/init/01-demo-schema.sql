-- Single unified demo table: event_space_bookings
-- Standard AUTO_INCREMENT PRIMARY KEY on nid + UNIQUE KEY (room_code, booking_period WITHOUT OVERLAPS).

USE drupal;

CREATE TABLE IF NOT EXISTS event_space_bookings (
    nid INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    room_code VARCHAR(32) NOT NULL,
    event_title VARCHAR(200) NOT NULL,
    speaker VARCHAR(150) NOT NULL,
    track VARCHAR(120) NOT NULL,
    summary TEXT NOT NULL,
    valid_from DATETIME NOT NULL,
    valid_to DATETIME NOT NULL,
    PERIOD FOR booking_period (valid_from, valid_to),
    UNIQUE KEY uq_room_booking_period (room_code, booking_period WITHOUT OVERLAPS)
) ENGINE=InnoDB;
