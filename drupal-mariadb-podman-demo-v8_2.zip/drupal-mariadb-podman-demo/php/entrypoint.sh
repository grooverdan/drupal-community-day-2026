#!/usr/bin/env bash
set -e

DEFAULT_SITE_DIR="/var/www/html/web/sites/default"
AI_VDB_VER="${AI_VDB_MARIADB_VERSION:-1.0.x-dev@dev}"

# Bootstrap Drupal 11 + MariaDB VDB + Ollama AI Provider on first run
if [ ! -f /var/www/html/composer.json ]; then
  echo ">>> Creating Drupal 11 project via Composer in temporary directory..."
  rm -rf /tmp/drupal-build
  composer create-project drupal/recommended-project:^11 /tmp/drupal-build --no-interaction

  echo ">>> Moving Drupal project into /var/www/html..."
  cp -a /tmp/drupal-build/. /var/www/html/
  rm -rf /tmp/drupal-build

  echo ">>> Requiring Drush, Drupal AI, Ollama Provider (@RC), and MariaDB VDB Provider (${AI_VDB_VER})..."
  composer require \
    drush/drush \
    drupal/ai \
    'drupal/ai_provider_ollama:^1.2@RC' \
    "drupal/ai_vdb_provider_mariadb:${AI_VDB_VER}" \
    drupal/search_api \
    --no-interaction

  echo ">>> Patching MariaDBVectorClient.php so CREATE TABLE uses IF NOT EXISTS..."
  VDB_CLIENT="/var/www/html/web/modules/contrib/ai_vdb_provider_mariadb/src/MariaDBVectorClient.php"
  if [ -f "${VDB_CLIENT}" ]; then
    sed -i 's/CREATE TABLE {$escaped_collection_name}/CREATE TABLE IF NOT EXISTS {$escaped_collection_name}/g' "${VDB_CLIENT}"
  fi

  echo ">>> Creating writable files, translations, and settings.php from default.settings.php..."
  mkdir -p "${DEFAULT_SITE_DIR}/files/translations"
  mkdir -p /var/www/html/config/sync

  cp "${DEFAULT_SITE_DIR}/default.settings.php" "${DEFAULT_SITE_DIR}/settings.php"

  cat << 'EOF' >> "${DEFAULT_SITE_DIR}/settings.php"

// Preconfigured demo settings (kept writable for live demos)
$settings['trusted_host_patterns'] = [
  '^localhost$',
  '^127\.0\.0\.1$',
  '^canberra_drupal_php$',
];
$settings['file_public_path'] = 'sites/default/files';
$settings['config_sync_directory'] = '../config/sync';
$config['locale.settings']['translation']['path'] = 'sites/default/files/translations';
EOF

  chown -R www-data:www-data "${DEFAULT_SITE_DIR}" /var/www/html/config
  chmod 0775 "${DEFAULT_SITE_DIR}" "${DEFAULT_SITE_DIR}/files" "${DEFAULT_SITE_DIR}/files/translations" /var/www/html/config/sync
  chmod 0664 "${DEFAULT_SITE_DIR}/settings.php"

  echo ">>> Installing custom Canberra Events module..."
  mkdir -p /var/www/html/web/modules/custom/canberra_events
  cp -r /opt/canberra_events/. /var/www/html/web/modules/custom/canberra_events/

  echo ">>> Installing Drupal site (note: drush site:install drops pre-existing tables)..."
  ./vendor/bin/drush site:install standard \
    --db-url="mysql://${DRUPAL_DB_USER}:${DRUPAL_DB_PASSWORD}@${DRUPAL_DB_HOST}/${DRUPAL_DB_NAME}" \
    --site-name="DrupalSouth Community Day Canberra 2026" \
    --account-name="admin" \
    --account-pass="admin" \
    -y

  echo ">>> Enabling modules (including datetime_range and views_ui for Semantic Search Views)..."
  ./vendor/bin/drush en -y datetime datetime_range views_ui search_api ai ai_search ai_provider_ollama ai_vdb_provider_mariadb canberra_events

  echo ">>> Creating event_space_bookings and seeding DrupalSouth Community Day 2026 schedule..."
  ./vendor/bin/drush php:script /usr/local/bin/seed_schedule.php
  ./vendor/bin/drush cr
fi

# Always ensure MariaDBVectorClient.php has IF NOT EXISTS on container restart
VDB_CLIENT="/var/www/html/web/modules/contrib/ai_vdb_provider_mariadb/src/MariaDBVectorClient.php"
if [ -f "${VDB_CLIENT}" ]; then
  sed -i 's/CREATE TABLE {$escaped_collection_name}/CREATE TABLE IF NOT EXISTS {$escaped_collection_name}/g' "${VDB_CLIENT}"
fi

# Always ensure default.settings.php -> settings.php exists and stays writable
if [ -d "${DEFAULT_SITE_DIR}" ]; then
  mkdir -p "${DEFAULT_SITE_DIR}/files/translations"
  if [ ! -f "${DEFAULT_SITE_DIR}/settings.php" ] && [ -f "${DEFAULT_SITE_DIR}/default.settings.php" ]; then
    cp "${DEFAULT_SITE_DIR}/default.settings.php" "${DEFAULT_SITE_DIR}/settings.php"
  fi
  chown -R www-data:www-data "${DEFAULT_SITE_DIR}/files"
  chmod -R 0775 "${DEFAULT_SITE_DIR}/files"
  if [ -f "${DEFAULT_SITE_DIR}/settings.php" ]; then
    chown www-data:www-data "${DEFAULT_SITE_DIR}" "${DEFAULT_SITE_DIR}/settings.php"
    chmod 0775 "${DEFAULT_SITE_DIR}"
    chmod 0664 "${DEFAULT_SITE_DIR}/settings.php"
  fi
fi

# Always sync custom module updates on container restart
if [ -d /opt/canberra_events ] && [ -d /var/www/html/web/modules/custom ]; then
  mkdir -p /var/www/html/web/modules/custom/canberra_events
  cp -r /opt/canberra_events/. /var/www/html/web/modules/custom/canberra_events/
fi

exec "$@"
