<?php

use Drupal\node\Entity\NodeType;
use Drupal\node\Entity\Node;
use Drupal\field\Entity\FieldStorageConfig;
use Drupal\field\Entity\FieldConfig;
use Drupal\Core\Database\Database;

$db = Database::getConnection();

// 0. Create event_space_bookings AFTER drush site:install (which drops existing tables)
$db->query("
  CREATE TABLE IF NOT EXISTS {event_space_bookings} (
    nid INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    room_code VARCHAR(32) NOT NULL,
    event_title VARCHAR(200) NOT NULL,
    speaker VARCHAR(150) NOT NULL,
    track VARCHAR(120) NOT NULL,
    summary TEXT NOT NULL,
    valid_from DATETIME NOT NULL,
    valid_to DATETIME NOT NULL,
    PERIOD FOR booking_period (valid_from, valid_to),
    UNIQUE KEY uq_room_booking_period (room_code, booking_period WITHOUT OVERLAPS)
  ) ENGINE=InnoDB
");

// 1. Create 'session' content type with Body, Room, Speaker, Track, and Stop/Start Date Range
if (!NodeType::load('session')) {
  $type = NodeType::create([
    'type' => 'session',
    'name' => 'Conference Session',
    'description' => 'DrupalSouth Community Day Canberra 2026 schedule session.',
  ]);
  $type->save();

  $fields = [
    'body' => ['type' => 'text_with_summary', 'label' => 'Abstract / Summary', 'widget' => 'text_textarea_with_summary', 'formatter' => 'text_default', 'settings' => []],
    'field_room' => ['type' => 'string', 'label' => 'Room', 'widget' => 'string_textfield', 'formatter' => 'string', 'settings' => []],
    'field_speaker' => ['type' => 'string', 'label' => 'Speaker(s)', 'widget' => 'string_textfield', 'formatter' => 'string', 'settings' => []],
    'field_track' => ['type' => 'string', 'label' => 'Track', 'widget' => 'string_textfield', 'formatter' => 'string', 'settings' => []],
    'field_schedule_window' => ['type' => 'daterange', 'label' => 'Schedule Start / Stop Time', 'widget' => 'daterange_default', 'formatter' => 'daterange_default', 'settings' => ['datetime_type' => 'datetime']],
  ];

  $form_display = \Drupal::service('entity_display.repository')->getFormDisplay('node', 'session', 'default');
  $view_display = \Drupal::service('entity_display.repository')->getViewDisplay('node', 'session', 'default');

  foreach ($fields as $name => $meta) {
    if (!FieldStorageConfig::loadByName('node', $name)) {
      FieldStorageConfig::create([
        'field_name' => $name,
        'entity_type' => 'node',
        'type' => $meta['type'],
        'settings' => $meta['settings'],
      ])->save();
    }
    if (!FieldConfig::loadByName('node', 'session', $name)) {
      FieldConfig::create([
        'field_name' => $name,
        'entity_type' => 'node',
        'bundle' => 'session',
        'label' => $meta['label'],
      ])->save();
    }
    $form_display->setComponent($name, ['type' => $meta['widget']]);
    $view_display->setComponent($name, ['type' => $meta['formatter']]);
  }
  $form_display->save();
  $view_display->save();
}

// 2. Full DrupalSouth Community Day 2026 Schedule (Thursday 19 Nov & Friday 20 Nov 2026)
$sessions = [
  // Thursday 19 Nov 2026 - Hellenic Club, Woden
  ['OLYMPUS', 'Opening Remarks & Keynote / Group Photo', 'DrupalSouth Committee', 'Keynote', '2026-11-19 09:00:00', '2026-11-19 09:25:00', 'Welcome to DrupalSouth Community Day Canberra 2026 at the Hellenic Club in Woden, followed by the opening keynote and group photo.'],
  ['OLYMPUS', 'Ask six people: rapid testing for non-researchers', 'Tori Sanderson', 'UX, Case study', '2026-11-19 09:30:00', '2026-11-19 10:00:00', 'Practical usability testing methods anyone on a delivery team can run quickly with six participants to validate designs without a dedicated research lab.'],
  ['APOLLO', 'Putting the hyper into hypermedia: htmx 4 in Drupal', 'Brendan Tuckerman', 'Development', '2026-11-19 09:30:00', '2026-11-19 10:00:00', 'Exploring how htmx 4 brings modern interactive UI transitions and partial page swaps to server-rendered Drupal applications without heavy JavaScript frameworks.'],
  ['OLYMPUS', 'Loud and Clear: Listening Well in a Noisy World', 'Fonda Duffy', 'People & Strategy, Case study', '2026-11-19 10:05:00', '2026-11-19 10:35:00', 'Strategies for active listening, stakeholder alignment, and clear communication across complex digital teams and government programs.'],
  ['APOLLO', "Not your grandad's Drupal", 'Lee Rowlands', 'Development', '2026-11-19 10:05:00', '2026-11-19 10:35:00', 'A tour of modern Drupal 11 architecture, attributes, hooks, recipes, and contemporary PHP patterns that make Drupal faster and cleaner to build on.'],
  ['OLYMPUS', 'Drupal Feud', 'Community Hosts', 'Community', '2026-11-19 11:00:00', '2026-11-19 11:20:00', 'Interactive community game show pitting teams against each other on Drupal trivia, module history, and Canberra tech culture.'],
  ['OLYMPUS', 'Does Discovery have a branding problem?', 'Morgan Goulding', 'UX, People & Strategy', '2026-11-19 11:20:00', '2026-11-19 11:50:00', 'Rethinking how discovery phases are positioned and run so stakeholders see tangible user outcomes rather than endless slide decks.'],
  ['APOLLO', 'Composition over Maintenance', 'Andrey Simonov', 'Architecture, Development', '2026-11-19 11:20:00', '2026-11-19 11:50:00', 'Designing modular Drupal architectures and recipes that favour composable building blocks over bespoke custom code that becomes costly to maintain.'],
  ['OLYMPUS', 'Accessibility as architecture', 'Rikki Bochow', 'Accessibility, Architecture, UX', '2026-11-19 11:55:00', '2026-11-19 12:25:00', 'Embedding WCAG accessibility requirements into design systems, content models, and component architecture from day one rather than treating audits as an afterthought.'],
  ['APOLLO', 'A SKILL.md for Drupal', 'Jeannie Panting', 'AI, Development', '2026-11-19 11:55:00', '2026-11-19 12:25:00', 'Structuring reusable AI agent skills and repository instructions with SKILL.md so coding assistants understand Drupal conventions, APIs, and project standards.'],
  ['OLYMPUS', 'Designing encapsulated content', 'Angus Gordon', 'Content, Architecture', '2026-11-19 12:30:00', '2026-11-19 13:00:00', 'Structuring portable, self-contained content models in Drupal so editorial teams can reuse components cleanly across channels and layouts.'],
  ['APOLLO', 'Inside GovCMS Rules as Code', 'Phillipa Martin & Suchi Garg', 'GovCMS, Development, Architecture', '2026-11-19 12:30:00', '2026-11-19 13:00:00', 'How GovCMS translates policy and legislative logic into machine-executable Rules as Code integrated with public-sector digital services.'],
  ['OLYMPUS', 'New agency, new voice', 'Tim Gay & Shannon Li', 'Content, Case study, People & Strategy', '2026-11-19 13:40:00', '2026-11-19 14:10:00', 'Establishing a cohesive brand voice, editorial governance, and content strategy when launching a newly formed government agency on Drupal.'],
  ['APOLLO', 'How we implemented AI search on GovCMS', 'Adam Bramley', 'GovCMS, AI, Case study', '2026-11-19 13:40:00', '2026-11-19 14:10:00', 'Architecture, vector embeddings, and Search API integration lessons from deploying semantic AI search across GovCMS websites.'],
  ['OLYMPUS', 'Give editors the keys', 'Matt Commons', 'Content, UX', '2026-11-19 14:15:00', '2026-11-19 14:45:00', 'Empowering content authors with intuitive page-building workflows, guardrails, and live previews without requiring developer intervention for every layout change.'],
  ['APOLLO', 'GovCMS security features', 'Janna Malikova', 'GovCMS, Development, Security', '2026-11-19 14:15:00', '2026-11-19 14:45:00', 'Deep dive into platform hardening, automated patching, WAF protections, and compliance controls built into GovCMS.'],
  ['OLYMPUS', 'A structured way to explore AI enablement', 'Julia Topliss & Emma Kelson', 'AI, People & Strategy', '2026-11-19 14:50:00', '2026-11-19 15:20:00', 'A practical framework for evaluating AI opportunities, managing organisational risk, and guiding teams from experimentation to sustainable adoption.'],
  ['APOLLO', 'Be Lazy - get the DB to do that', 'Daniel Black', 'Development, Architecture', '2026-11-19 14:50:00', '2026-11-19 15:20:00', 'Offloading temporal overlap constraints, system-versioned audit history, and native HNSW vector search directly into MariaDB 11.8/12.3 LTS instead of complex PHP boilerplate.'],
  ['OLYMPUS', 'Closing Remarks & Networking Event', 'DrupalSouth Committee', 'Community', '2026-11-19 15:20:00', '2026-11-19 17:30:00', 'Wrap-up of Day 1 sessions followed by drinks and community networking at the Hellenic Club.'],
  // Friday 20 Nov 2026 - Day 2 at Pragma Office, Canberra City
  ['PRAGMA-CITY', 'Moving Issue Queues to GitLab for Drupal Projects', 'Vladimir Roudakov', 'Contribution, Tooling', '2026-11-20 09:45:00', '2026-11-20 10:15:00', 'Hands-on guide to navigating the Drupal GitLab issue queue transition, creating and reviewing Merge Requests, and awarding contribution credits.'],
  ['PRAGMA-CITY', 'Dispatch', 'Tristan Blattman', 'Cloud, DevOps', '2026-11-20 10:30:00', '2026-11-20 11:00:00', 'Modern deployment workflows and platform automation insights from Upsun at Day 2 of DrupalSouth Community Day Canberra.'],
];

foreach ($sessions as $s) {
  [$room, $title, $speaker, $track, $start, $end, $summary] = $s;

  $iso_start = str_replace(' ', 'T', $start);
  $iso_end = str_replace(' ', 'T', $end);

  $node = Node::create([
    'type' => 'session',
    'title' => $title,
    'body' => ['value' => $summary, 'format' => 'plain_text'],
    'field_room' => $room,
    'field_speaker' => $speaker,
    'field_track' => $track,
    'field_schedule_window' => [
      'value' => $iso_start,
      'end_value' => $iso_end,
    ],
    'status' => 1,
  ]);
  $node->save();

  $db->insert('event_space_bookings')
    ->fields([
      'nid' => $node->id(),
      'room_code' => $room,
      'event_title' => $title,
      'speaker' => $speaker,
      'track' => $track,
      'summary' => $summary,
      'valid_from' => $start,
      'valid_to' => $end,
    ])
    ->execute();
}

echo "Seeded " . count($sessions) . " DrupalSouth Canberra 2026 sessions into nodes and event_space_bookings.\n";
